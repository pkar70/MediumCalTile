﻿Imports Windows.Storage
Imports Windows.ApplicationModel.Background
Imports Windows.ApplicationModel.Appointments
Imports Windows.Data.Xml.Dom
Imports Windows.UI.Notifications

''' <summary>
''' Provides application-specific behavior to supplement the default Application class.
''' </summary>
NotInheritable Class App
    Inherits Application

    Dim taskBack As BackgroundTaskRegistration
    Public Function GetDTygName(iDay As Integer) As String
        Select Case iDay
            Case 0
                GetDTygName = "niedziela"
            Case 1
                GetDTygName = "poniedziaĹ‚ek"
            Case 2
                GetDTygName = "wtorek"
            Case 3
                GetDTygName = "Ĺ›roda"
            Case 4
                GetDTygName = "czwartek"
            Case 5
                GetDTygName = "piÄ…tek"
            Case 6
                GetDTygName = "sobota"
            Case 9
                GetDTygName = "jutro"
            Case 10
                GetDTygName = "ndz"
            Case 11
                GetDTygName = "pon"
            Case 12
                GetDTygName = "wtorek"
            Case 13
                GetDTygName = "Ĺ›roda"
            Case 14
                GetDTygName = "czw"
            Case 15
                GetDTygName = "piÄ…tek"
            Case 16
                GetDTygName = "sobota"
            Case Else
                GetDTygName = "(dztyg)"
        End Select
    End Function
    Public Function GodzMin2Txt(iHr As Integer, iMin As Integer) As String
        Dim sTmp As String
        sTmp = iHr & ":" & iMin
        If iMin = 0 Then sTmp = sTmp & "0"
        GodzMin2Txt = sTmp
    End Function
    Private Function CreateEventDescr(sTitle As String, sWhen As Date, sToWhen As Date, sWhere As String) As String
        Dim sTmp As String
        If sWhen.DayOfYear = Date.Now.DayOfYear Then
            If sWhen <= Date.Now Then
                sTmp = "do " & GodzMin2Txt(sToWhen.Hour, sToWhen.Minute) & "  (" & sWhere & ")"
            Else
                sTmp = GodzMin2Txt(sWhen.Hour, sWhen.Minute) & "  (" & sWhere & ")"
            End If
        ElseIf sWhen.DayOfYear = Date.Now.DayOfYear + 1 Then
            sTmp = GetDTygName(9) & ", " & GodzMin2Txt(sWhen.Hour, sWhen.Minute) & "  (" & sWhere & ")"
        Else
            sTmp = GetDTygName(sWhen.DayOfWeek) & ", " & GodzMin2Txt(sWhen.Hour, sWhen.Minute) & "  (" & sWhere & ")"
        End If

        sTmp = "<text hint-style='body'>" & sTitle & "</text>" & vbCrLf &
               "<text hint-style='captionSubtle'>(app) " & sTmp & "</text>" & vbCrLf
        '        "<text hint-style='captionSubtle'></text>"

        CreateEventDescr = sTmp

        ' rozmiary czcionki:
        ' caption   12 regular
        ' body      15 regular
        ' base      15 semibold
        ' subtitle  20 regular
        ' title     24 semilight
        ' subheader 34 light
        ' header    46 light


    End Function
    Public Async Function Calendar2TileAsync() As Task(Of String)

        Dim oStore As AppointmentStore
        oStore = Await AppointmentManager.RequestStoreAsync(AppointmentStoreAccessType.AllCalendarsReadOnly)

        Dim oCalendars As IReadOnlyList(Of Appointment)
        oCalendars = Await oStore.FindAppointmentsAsync(Date.Now, TimeSpan.FromDays(7))
        Dim oApp As Appointment
        Dim iCnt As Integer
        Dim sEvents, sEvents1 As String
        iCnt = 0
        sEvents = ""
        sEvents1 = ""

        For Each oApp In oCalendars
            If iCnt > 2 Then Exit For
            If iCnt = 2 Then
                sEvents1 = CreateEventDescr(oApp.Subject, oApp.StartTime.DateTime, oApp.StartTime.DateTime + oApp.Duration, oApp.Location)
            Else
                ' If oApp.AllDay Then
                sEvents = sEvents & CreateEventDescr(oApp.Subject, oApp.StartTime.DateTime, oApp.StartTime.DateTime + oApp.Duration, oApp.Location)
            End If
            iCnt = iCnt + 1
        Next

        Dim sXml As String
        sXml = "<tile><visual>"

        sXml = sXml & "<binding template ='TileMedium' branding='none'>"
        sXml = sXml & sEvents & "<text hint-style='captionSubtle'></text>"
        sXml = sXml & "<text hint-style='subheader' hint-align='right'>" &
            GetDTygName(Date.Now.DayOfWeek + 10) & ", " & Date.Now.Day & "</text>"
        sXml = sXml & "</binding>"

        sXml = sXml & "<binding template ='TileWide' branding='none'>"
        sXml = sXml & "<group><subgroup hint-weight='5'>"
        sXml = sXml & sEvents & sEvents1
        sXml = sXml & "</subgroup>"
        sXml = sXml & "<subgroup hint-weight='1'>"
        sXml = sXml & "<text hint-style='subtitle' hint-align='right'> </text>"    ' puste zeby data na dole
        sXml = sXml & "<text hint-style='title' hint-align='right'> </text>"
        sXml = sXml & "<text hint-style='header' hint-align='right'>" & Date.Now.Day & "</text>"
        sXml = sXml & "</subgroup></group>"
        sXml = sXml & "</binding>"

        sXml = sXml & "</visual></tile>"

        Dim oXml As New XmlDocument
        oXml.LoadXml(sXml)

        Dim oTile = New Windows.UI.Notifications.TileNotification(oXml)

        TileUpdateManager.CreateTileUpdaterForApplication().Update(oTile)

        Return sXml

    End Function

    ''' <summary>
    ''' Invoked when the application is launched normally by the end user.  Other entry points
    ''' will be used when the application is launched to open a specific file, to display
    ''' search results, and so forth.
    ''' </summary>
    ''' <param name="e">Details about the launch request and process.</param>
    Protected Overrides Sub OnLaunched(e As Windows.ApplicationModel.Activation.LaunchActivatedEventArgs)

        ApplicationData.Current.LocalSettings.Values("bCallFromTile") = 1
        If e.TileActivatedInfo Is Nothing Then
            ApplicationData.Current.LocalSettings.Values("bCallFromTile") = 0
        End If

        Dim rootFrame As Frame = TryCast(Window.Current.Content, Frame)

        ' Do not repeat app initialization when the Window already has content,
        ' just ensure that the window is active

        If rootFrame Is Nothing Then
            ' Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = New Frame()

            AddHandler rootFrame.NavigationFailed, AddressOf OnNavigationFailed

            If e.PreviousExecutionState = ApplicationExecutionState.Terminated Then
                ' TODO: Load state from previously suspended application
            End If
            ' Place the frame in the current Window
            Window.Current.Content = rootFrame
        End If

        If e.PrelaunchActivated = False Then
            If rootFrame.Content Is Nothing Then
                ' When the navigation stack isn't restored navigate to the first page,
                ' configuring the new page by passing required information as a navigation
                ' parameter
                rootFrame.Navigate(GetType(MainPage), e.Arguments)
            End If

            ' Ensure the current window is active
            Window.Current.Activate()
        End If

    End Sub

    ''' <summary>
    ''' Invoked when Navigation to a certain page fails
    ''' </summary>
    ''' <param name="sender">The Frame which failed navigation</param>
    ''' <param name="e">Details about the navigation failure</param>
    Private Sub OnNavigationFailed(sender As Object, e As NavigationFailedEventArgs)
        Throw New Exception("Failed to load Page " + e.SourcePageType.FullName)
    End Sub

    ''' <summary>
    ''' Invoked when application execution is being suspended.  Application state is saved
    ''' without knowing whether the application will be terminated or resumed with the contents
    ''' of memory still intact.
    ''' </summary>
    ''' <param name="sender">The source of the suspend request.</param>
    ''' <param name="e">Details about the suspend request.</param>
    Private Sub OnSuspending(sender As Object, e As SuspendingEventArgs) Handles Me.Suspending
        Dim deferral As SuspendingDeferral = e.SuspendingOperation.GetDeferral()
        ' TODO: Save application state and stop any background activity
        deferral.Complete()
    End Sub

End Class

﻿' The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

Imports Windows.ApplicationModel.Appointments
Imports Windows.ApplicationModel.Background
Imports Windows.Data.Xml.Dom
Imports Windows.Storage
Imports Windows.UI.Notifications
''' <summary>
''' wedle
''' https://docs.microsoft.com/en-us/windows/uwp/controls-and-patterns/tiles-and-notifications-create-adaptive-tiles
''' </summary>
Public NotInheritable Class MainPage
    Inherits Page

    Private Timer1 As DispatcherTimer
    Dim oAppTrig As ApplicationTrigger

    Protected Overrides Async Sub OnNavigatedTo(e As NavigationEventArgs)
        MyBase.OnNavigatedTo(e)

        Dim oBAS As BackgroundAccessStatus
        oBAS = Await BackgroundExecutionManager.RequestAccessAsync()

        If oBAS = BackgroundAccessStatus.AlwaysAllowed Or oBAS = BackgroundAccessStatus.AllowedSubjectToSystemPolicy Then

            Dim bTimer As Boolean = False
            Dim bUser As Boolean = False
            Dim bApp As Boolean = False

            For Each oTask In BackgroundTaskRegistration.AllTasks
                If oTask.Value.Name = "MediumCalTileBackgroundTimer" Then bTimer = True
                If oTask.Value.Name = "MediumCalTileBackgroundUser" Then bUser = True
                If oTask.Value.Name = "MediumCalTileBackgroundApp" Then bApp = True
            Next

            If Not bTimer Or Not bUser Or Not bApp Then

                ' https://docs.microsoft.com/en-us/windows/uwp/launch-resume/create-And-register-an-inproc-background-task
                Dim builder As BackgroundTaskBuilder = New BackgroundTaskBuilder
                Dim oRet As BackgroundTaskRegistration

                If Not bTimer Then
                    builder.SetTrigger(New TimeTrigger(15, False))  ' nie moze byc mniej niz 15 minut!
                    builder.Name = "MediumCalTileBackgroundTimer"
                    builder.TaskEntryPoint = "BackgroundTasks.UpdateLiveTile"
                    oRet = builder.Register()
                End If

                If Not bUser Then
                    builder.SetTrigger(New SystemTrigger(SystemTriggerType.UserPresent, False))  ' user sie pojawia
                    builder.Name = "MediumCalTileBackgroundUser"
                    builder.TaskEntryPoint = "BackgroundTasks.UpdateLiveTile"
                    oRet = builder.Register()
                End If

                If Not bApp Then
                    oAppTrig = New ApplicationTrigger
                    builder.SetTrigger(oAppTrig)  ' do wywolywania metody
                    builder.Name = "MediumCalTileBackgroundApp"
                    builder.TaskEntryPoint = "BackgroundTasks.UpdateLiveTile"
                    oRet = builder.Register()
                End If

            End If
        End If

    End Sub
    Private Async Sub OnLoaded_Main(sender As Object, e As RoutedEventArgs)
        Timer1 = New DispatcherTimer With {
            .Interval = TimeSpan.FromSeconds(1)
        }
        AddHandler Timer1.Tick, AddressOf Timer1_Tick
        Timer1.Start()

        ApplicationData.Current.LocalSettings.Values("sRunLog") = ""

        If Windows.Storage.ApplicationData.Current.LocalSettings.Values("bCallFromTile").ToString = "1" Then
            Await AppointmentManager.ShowTimeFrameAsync(Date.Now, TimeSpan.FromHours(24))
        End If

        tbModif.Text = "Build " & Package.Current.Id.Version.Major & "." &
            Package.Current.Id.Version.Minor & "." & Package.Current.Id.Version.Build

    End Sub
    Private Async Sub Timer1_Tick()
        ' Timer1.Interval = TimeSpan.FromMinutes(5)
        Timer1.Stop()

        Await oAppTrig.RequestAsync
        ' Dim sTmp As String = Await CType(Application.Current, App).Calendar2TileAsync()
    End Sub
    Private Sub bCheck_Click(sender As Object, e As RoutedEventArgs)
        Dim sTmp As String
        sTmp = Date.Now.Minute.ToString & ": "
        For Each oTask In BackgroundTaskRegistration.AllTasks
            If oTask.Value.Name = "MediumCalTileBackgroundTimer" Then sTmp = sTmp & "T"
            If oTask.Value.Name = "MediumCalTileBackgroundUser" Then sTmp = sTmp & "u"
            If oTask.Value.Name = "MediumCalTileBackgroundApp" Then sTmp = sTmp & "A"
        Next
        tbInfo.Text = sTmp

        sTmp = ApplicationData.Current.LocalSettings.Values("sRunLog").ToString
        tbLog.Text = sTmp

    End Sub
    Private Async Sub bUpdate_Click(sender As Object, e As RoutedEventArgs)
        ' Await CType(Application.Current, App).Calendar2TileAsync()
        Await oAppTrig.RequestAsync
    End Sub


End Class

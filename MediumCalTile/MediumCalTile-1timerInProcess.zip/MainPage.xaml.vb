﻿' The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

Imports Windows.ApplicationModel.Appointments
Imports Windows.Data.Xml.Dom
Imports Windows.UI.Notifications
''' <summary>
''' wedle
''' https://docs.microsoft.com/en-us/windows/uwp/controls-and-patterns/tiles-and-notifications-create-adaptive-tiles
''' </summary>
Public NotInheritable Class MainPage
    Inherits Page

    Private oApplic As App
    'Private Timer1 As DispatcherTimer

    Sub CreateTileTest()

        Dim sEvents As String
        Dim sData As Date
        sData = Date.Now

        sEvents = oApplic.CreateEventDescr("IEEE p7010", sData, "inet")
        sEvents = sEvents & oApplic.CreateEventDescr("Wyklad numer 1", sData, "f1 232")


        Dim sXml As String
        sXml = "<tile><visual>"

        sXml = sXml & "<binding template ='TileMedium' branding='none'>"
        sXml = sXml & sEvents
        sXml = sXml & "<text hint-style='subheader' hint-align='right'>" &
            oApplic.GetDTygName(sData.DayOfWeek + 10) & ", " & sData.Day & "</text>"
        sXml = sXml & "</binding>"

        sXml = sXml & "<binding template ='TileWide' branding='none'>"
        sXml = sXml & "<group><subgroup hint-weight='5'>"
        sXml = sXml & sEvents   ' mogloby byc jeszcze jedno event
        sXml = sXml & "</subgroup>"
        sXml = sXml & "<subgroup hint-weight='1'>"
        sXml = sXml & "<text hint-style='title' hint-align='right'> </text>"    ' puste zeby data na dole
        sXml = sXml & "<text hint-style='title' hint-align='right'> </text>"
        sXml = sXml & "<text hint-style='title' hint-align='right'> </text>"
        sXml = sXml & "<text hint-style='header' hint-align='right'>" & sData.Day & "</text>"
        sXml = sXml & "</subgroup></group>"
        sXml = sXml & "</binding>"

        sXml = sXml & "</visual></tile>"


        Dim oXml As XmlDocument
        oXml = New XmlDocument
        oXml.LoadXml(sXml)

        Dim oTile = New Windows.UI.Notifications.TileNotification(oXml)

        TileUpdateManager.CreateTileUpdaterForApplication().Update(oTile)
    End Sub


    Private Sub OnLoaded_Main(sender As Object, e As RoutedEventArgs)
        'Timer1 = New DispatcherTimer
        'Timer1.Interval = TimeSpan.FromSeconds(1)
        'AddHandler Timer1.Tick, AddressOf Timer1_Tick
        'Timer1.Start()

        oApplic = Application.Current

        If Windows.Storage.ApplicationData.Current.LocalSettings.Values("bCallFromTile") = 1 Then
            AppointmentManager.ShowTimeFrameAsync(Date.Now, TimeSpan.FromHours(24))
        End If

        tbModif.Text = "Build " & Package.Current.Id.Version.Build

    End Sub
    'Private Async Sub Timer1_Tick()
    '    Timer1.Interval = TimeSpan.FromMinutes(5)
    '    ReadCal()
    'End Sub

    Private Sub bUpdate_Click(sender As Object, e As RoutedEventArgs)
        oApplic.Calendar2Tile()
    End Sub
End Class
